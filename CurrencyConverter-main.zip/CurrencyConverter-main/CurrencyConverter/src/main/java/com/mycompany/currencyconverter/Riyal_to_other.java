package com.mycompany.currencyconverter;

public class Riyal_to_other {
    
    public static void Riyal_to_other(double amt) {

        System.out.println("1 Riyal = " + 0.27 + " Dollar ");
        System.out.println();

        System.out.println(amt + " Riyal = " + (amt * 0.27) + " Dollar ");
        System.out.println();

        System.out.println("1 Riyal = " + 0.25 + " Euro ");
        System.out.println();

        System.out.println(amt + " Riyal = " + (amt * 0.25) + " Euro ");
        System.out.println();

        System.out.println("1 Riyal = " + 34.66 + " yen ");
        System.out.println();

        System.out.println(amt + " Riyal = " + (amt * 34.66) + " yen ");
        System.out.println();

        System.out.println("1 Riyal = " + 1.79 + " yuan ");
        System.out.println();

        System.out.println(amt + " Riyal = " + (amt * 1.79) + " yuan ");
        System.out.println();
        
        System.out.println("1 Riyal = " + 0.22 + " pound sterling  ");
        System.out.println();

        System.out.println(amt + " Riyal = " + (amt * 0.22) + " pound sterling  ");
        System.out.println();

    }

    
}
