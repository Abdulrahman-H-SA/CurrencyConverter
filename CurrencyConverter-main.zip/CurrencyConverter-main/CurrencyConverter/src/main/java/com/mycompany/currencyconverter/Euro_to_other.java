package com.mycompany.currencyconverter;

public class Euro_to_other {
    
     public static void Euro_to_other(double amt) {

        System.out.println("1 Euro = " + 4.05 + " Riyal ");
        System.out.println();

        System.out.println(amt + " Euro = " + (amt * 4.05) + " Riyal ");
        System.out.println();

        System.out.println("1 Euro = " + 1.08 + " Dollar ");
        System.out.println();

        System.out.println(amt + " Euro = " + (amt * 1.08) + " Dollar ");
        System.out.println();

        System.out.println("1 Euro = " + 140.59 + " yen ");
        System.out.println();

        System.out.println(amt + " Euro = " + (amt * 140.59) + " yen ");
        System.out.println();

        System.out.println("1 Euro = " + 7.27 + " yuan ");
        System.out.println();

        System.out.println(amt + " Euro = " + (amt * 7.27) + " yuan ");
        System.out.println();
        
        System.out.println("1 Euro = " + 0.89 + " pound sterling ");
        System.out.println();

        System.out.println(amt + " Euro = " + (amt * 0.89) + " pound sterling ");
        System.out.println();

    }
    
}
