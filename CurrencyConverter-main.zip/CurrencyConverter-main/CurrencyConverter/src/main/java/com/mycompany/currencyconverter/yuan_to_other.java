package com.mycompany.currencyconverter;

public class yuan_to_other {
    
        public static void yuan_to_other(double amt) {

        System.out.println("1 yuan = " + 0.56 + " Riyal ");
        System.out.println();

        System.out.println(amt + " yuan = " + (amt * 0.56) + " Riyal ");
        System.out.println();

        System.out.println("1 yuan = " + 0.15 + " Dollar ");
        System.out.println();

        System.out.println(amt + " yuan = " + (amt * 0.15) + " Dollar ");
        System.out.println();

        System.out.println("1 yuan = " + 0.14 + " Euro");
        System.out.println();

        System.out.println(amt + " yuan = " + (amt * 0.14) + " Euro ");
        System.out.println();

        System.out.println("1 yuan = " + 19.27 + " yen ");
        System.out.println();

        System.out.println(amt + " yuan = " + (amt * 19.27) + " yen ");
        System.out.println();
        
        System.out.println("1 yuan = " + 0.12 + " pound sterling ");
        System.out.println();

        System.out.println(amt + " yuan = " + (amt * 0.12) + " pound sterling ");
        System.out.println();

    }
    
}
