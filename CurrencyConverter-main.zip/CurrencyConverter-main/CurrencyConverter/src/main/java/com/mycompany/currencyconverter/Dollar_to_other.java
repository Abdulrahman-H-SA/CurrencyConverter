package com.mycompany.currencyconverter;

public class Dollar_to_other {
    
    public static void Dollar_to_other(double amt) {

        System.out.println("1 Dollar = " + 3.76 + " Riyal ");
        System.out.println();

        System.out.println(amt + " Dollar = " + (amt * 3.76) + " Riyal ");
        System.out.println();

        System.out.println("1 Dollar= " + 0.93 + " Euro ");
        System.out.println();

        System.out.println(amt + " Dollar = " + (amt * 0.93) + " Euro ");
        System.out.println();

        System.out.println("1 Dollar = " + 130.20 + " yen ");
        System.out.println();

        System.out.println(amt + " Dollar = " + (amt * 130.20) + " yen ");
        System.out.println();

        System.out.println("1 Dollar = " + 6.74 + " yuan ");
        System.out.println();

        System.out.println(amt + " Dollar = " + (amt * 6.74) + " yuan ");
        System.out.println();

        System.out.println("1 Dollar = " + 0.83 + " pound sterling ");
        System.out.println();

        System.out.println(amt + " Dollar = " + (amt * 0.83) + " pound sterling ");
        System.out.println();
    }
    
}
