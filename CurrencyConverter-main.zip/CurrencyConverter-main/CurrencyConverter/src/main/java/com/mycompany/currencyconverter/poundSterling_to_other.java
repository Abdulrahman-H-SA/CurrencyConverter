package com.mycompany.currencyconverter;

public class poundSterling_to_other {
    
    public static void poundSterling_to_other(double amt) {

        System.out.println("1 pound sterling  = " + 4.51 + " Riyal ");
        System.out.println();

        System.out.println(amt + " pound sterling = " + (amt * 4.51) + " Riyal ");
        System.out.println();

        System.out.println("1 pound sterling = " + 1.20 + " Dollar ");
        System.out.println();

        System.out.println(amt + " pound sterling = " + (amt * 1.20) + " Dollar ");
        System.out.println();

        System.out.println("1 pound sterling = " + 1.13 + " Euro ");
        System.out.println();

        System.out.println(amt + " pound sterling = " + (amt * 1.13) + " Euro ");
        System.out.println();

        System.out.println("1 pound sterling = " + 161.27 + " yen ");
        System.out.println();

        System.out.println(amt + " pound sterling = " + (amt * 161.27) + " yen ");
        System.out.println();
        
        System.out.println("1 pound sterling = " + 8.24 + " yuan ");
        System.out.println();

        System.out.println(amt + " pound sterling = " + (amt * 8.24) + " yuan ");
        System.out.println();

    }

    
}
