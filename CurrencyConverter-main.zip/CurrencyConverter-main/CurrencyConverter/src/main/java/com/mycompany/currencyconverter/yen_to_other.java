package com.mycompany.currencyconverter;

public class yen_to_other {
    
    public static void yen_to_other(double amt) {

        System.out.println("1 yen = " + 0.029 + " Riyal ");
        System.out.println();

        System.out.println(amt + " yen = " + (amt * 0.029) + " Riyal ");
        System.out.println();

        System.out.println("1 yen = " + 0.0077 + " Dollar ");
        System.out.println();

        System.out.println(amt + " yen = " + (amt * 0.0077) + " Dollar ");
        System.out.println();

        System.out.println("1 yen = " + 0.0071 + " Euro ");
        System.out.println();

        System.out.println(amt + " yen = " + (amt * 0.0071) + " Euro ");
        System.out.println();

        System.out.println("1 yen = " + 0.052 + " yuan ");
        System.out.println();

        System.out.println(amt + " yen = " + (amt * 0.052) + " yuan ");
        System.out.println();
        
        System.out.println("1 yen = " + 0.0062 + " pound sterling ");
        System.out.println();

        System.out.println(amt + " yen = " + (amt * 0.0062) + " pound sterling ");
        System.out.println();

    }
    
}